package com.cxz.maven;
public class Hello {
	public String sayHello(String name){
		return "Hello " + name + "!";
		}
}