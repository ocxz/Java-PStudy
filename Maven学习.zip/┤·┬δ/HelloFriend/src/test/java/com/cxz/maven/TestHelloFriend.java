package com.cxz.maven;
import static junit.framework.Assert.assertEquals;
import org.junit.Test;
import com.cxz.maven.Hello;
public class TestHelloFriend{
	@Test
	public void testHelloFriend() {
		HelloFriend helloFriend = new HelloFriend();
		String results = helloFriend.sayHelloToFriend("cxz");
		assertEquals("Hello cxz! I am John", results);
	}
}
