package com.cxz.maven;

public class Good {

}
