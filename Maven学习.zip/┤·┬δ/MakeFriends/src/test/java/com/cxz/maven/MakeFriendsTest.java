package com.cxz.maven;

import static junit.framework.Assert.assertEquals;
import org.junit.Test;

public class MakeFriendsTest {

	@Test
	public void testMakeFriends() {
		MakeFriends makeFriends = new MakeFriends();
		String str = makeFriends.makeFriends("mike");
		assertEquals("Hey,John make a friend please", str);
	}
}
